package com.mygdx.resources.game;

import java.util.HashMap;

public enum TileType {

    GRASS(1, true, "Grass"),
    DIRT(2, false, "Dirt"),
    SKY(3, false, "Sky"),
    LAVA(4, true, "Lava"),
    CLOUD(5, true, "Cloud"),
    STONE(6, true, "Stone");

    private int id;
    private boolean collidable;
    private String name;
    private int damage;

    public static final int TILE_SIZE = 16;


    private TileType (int i, boolean c, String n) {
        this(i,c,n, 0);
    }

    private TileType (int i, boolean c, String n, int d) {
        this.id = i;
        this.collidable = c;
        this.name = n;
        this.damage = d;
    }


    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public boolean getCollidable() {
        return collidable;
    }

    private static HashMap<Integer, TileType> tileMap;

    static {
        tileMap = new HashMap<Integer, TileType>();
        for (TileType t: TileType.values()) {
            tileMap.put(t.getId(),t);
        }
    }

    public static TileType getTyleType(int key) {
        return tileMap.get(key);
    }

}
